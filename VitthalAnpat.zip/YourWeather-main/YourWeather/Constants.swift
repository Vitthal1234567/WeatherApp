//  Constants.swift
//  Your Weather App
//
//  Created by Vitthal Anpat on 5/06/23.
//  Copyright © 2023 Vitthal Anpat. All rights reserved.
//

import Foundation

struct Constants {
    static let weatherViewController = "WeatherViewController"
    static let searchViewController = "SearchViewController"
    static let startViewController = "StartViewController"
    
    struct cells {
        static let searchTableViewCell = "SearchTableViewCell"
        static let selfLocationTableViewCell = "SelfLocationTableViewCell"
        static let hourlyCollectionViewCell = "HourlyCollectionViewCell"
        static let dailyCollectionViewCell = "DailyCollectionViewCell"
    }
    
}
