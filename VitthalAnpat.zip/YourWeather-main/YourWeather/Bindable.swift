//  Bindable.swift
//  Your Weather App
//
//  Created by Vitthal Anpat on 5/06/23.
//  Copyright © 2023 Vitthal Anpat. All rights reserved.
//

import Foundation

class Bindable<T> {
    typealias Listener = (T) -> Void
    private var listener: Listener?
    
    var value: T {
        didSet {
            listener?(value)
        }
    }
    
    init(_ value: T) {
        self.value = value
    }
    
    func bind(_ listener: Listener?) {
        self.listener = listener
        listener?(value)
    }
}
