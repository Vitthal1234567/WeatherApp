//  SearchTableViewCell.swift
//  Your Weather App
//
//  Created by Vitthal Anpat on 5/06/23.
//  Copyright © 2023 Vitthal Anpat. All rights reserved.
//

import UIKit

class SearchTableViewCell: UITableViewCell {

    @IBOutlet weak var cityName: UILabel!
    @IBOutlet weak var countryName: UILabel!
    
    func configure(filteredCities: SearchCellViewModel) {
        cityName.text = filteredCities.city
        countryName.text = filteredCities.country
        self.backgroundColor = .clear
    }

}
