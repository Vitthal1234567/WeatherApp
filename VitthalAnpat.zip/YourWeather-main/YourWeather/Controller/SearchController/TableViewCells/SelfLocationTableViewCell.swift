//  SelfLocationTableViewCell.swift
//  Your Weather App
//
//  Created by Vitthal Anpat on 5/06/23.
//  Copyright © 2023 Vitthal Anpat. All rights reserved.
//

import UIKit

class SelfLocationTableViewCell: UITableViewCell {

    @IBOutlet weak var imageViewCell: UIImageView!
    @IBOutlet weak var locationLabel: UILabel!
    
    func configure() {
        self.locationLabel.text = "Use current location".localize
    }
}
