# YourWeather

- I developed Weather App in order to learn API, URLSession, JSON, CoreLocation, Localization,AVKit.
- Used Openweathermap API.
- I accessed current weather data, 7 days, hourly data for any location including more then 200 000 cities.
# Result
https://user-images.githubusercontent.com/30414956/166903020-9ec06472-fd92-46ec-aa50-09ca62746cf3.mp4




